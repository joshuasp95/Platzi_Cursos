DROP TABLE people;

DROP DATABASE test_db;